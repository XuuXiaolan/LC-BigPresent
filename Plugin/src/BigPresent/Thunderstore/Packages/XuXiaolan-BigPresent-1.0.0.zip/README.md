# Big Present

- Has a chance of spawning anywhere near 10 to 20 different items.
- Has a chance to blow you up.
